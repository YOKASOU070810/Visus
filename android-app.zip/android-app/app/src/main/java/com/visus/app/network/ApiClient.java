package com.visus.app.network;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {
    private final String baseUrl;

    public ApiClient(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public void getHealth(TextCallback callback) {
        get("/health", callback);
    }

    private void get(String path, TextCallback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(baseUrl + path);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                int statusCode = connection.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        statusCode >= 200 && statusCode < 300
                                ? connection.getInputStream()
                                : connection.getErrorStream(),
                        StandardCharsets.UTF_8
                ));

                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    body.append(line);
                }

                if (statusCode >= 200 && statusCode < 300) {
                    callback.onSuccess(body.toString());
                } else {
                    callback.onError(new IllegalStateException("HTTP " + statusCode + ": " + body));
                }
            } catch (Exception exception) {
                callback.onError(exception);
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    public interface TextCallback {
        void onSuccess(String response);

        void onError(Exception exception);
    }
}

