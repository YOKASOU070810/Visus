package com.visus.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.visus.app.core.PermissionHelper;
import com.visus.app.network.ApiClient;

public class MainActivity extends Activity {
    private TextView statusText;
    private ApiClient apiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button checkApiButton = findViewById(R.id.checkApiButton);
        Button startAssistButton = findViewById(R.id.startAssistButton);

        PermissionHelper.requestMissingPermissions(
                this,
                new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }
        );

        apiClient = new ApiClient("http://10.0.2.2:8000");

        checkApiButton.setOnClickListener(view -> checkBackendHealth());
        startAssistButton.setOnClickListener(view ->
                statusText.setText("辅助模式入口已预留，后续接入摄像头、识别、语音和应急模块。")
        );
    }

    private void checkBackendHealth() {
        statusText.setText("正在检查后端连接...");
        apiClient.getHealth(new ApiClient.TextCallback() {
            @Override
            public void onSuccess(String response) {
                runOnUiThread(() -> statusText.setText("后端连接成功：" + response));
            }

            @Override
            public void onError(Exception exception) {
                runOnUiThread(() -> statusText.setText("后端连接失败：" + exception.getMessage()));
            }
        });
    }
}

