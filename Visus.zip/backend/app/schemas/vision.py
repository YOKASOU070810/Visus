from pydantic import BaseModel


class SceneDescriptionResponse(BaseModel):
    summary: str
    risk_level: str
    next_action: str

