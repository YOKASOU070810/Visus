from pydantic import BaseModel


class NavigationHintResponse(BaseModel):
    hint: str
    priority: str

