from pydantic import BaseModel


class LocationStatusResponse(BaseModel):
    tracking_enabled: bool
    message: str

