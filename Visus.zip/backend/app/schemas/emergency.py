from pydantic import BaseModel


class EmergencyResponse(BaseModel):
    alert_id: str
    status: str
    message: str

