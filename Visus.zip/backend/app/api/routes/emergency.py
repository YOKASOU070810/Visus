from fastapi import APIRouter

from app.schemas.emergency import EmergencyResponse
from app.services.emergency_service import EmergencyService

router = APIRouter(prefix="/api/emergency", tags=["emergency"])
service = EmergencyService()


@router.post("/alert", response_model=EmergencyResponse)
def create_alert() -> EmergencyResponse:
    return service.create_placeholder_alert()

