from fastapi import APIRouter

from app.schemas.location import LocationStatusResponse
from app.services.location_service import LocationService

router = APIRouter(prefix="/api/location", tags=["location"])
service = LocationService()


@router.get("/status", response_model=LocationStatusResponse)
def get_location_status() -> LocationStatusResponse:
    return service.get_placeholder_status()

