from fastapi import APIRouter, File, UploadFile

from app.schemas.vision import SceneDescriptionResponse
from app.services.vision_service import VisionService

router = APIRouter(prefix="/api/vision", tags=["vision"])
service = VisionService()


@router.post("/describe", response_model=SceneDescriptionResponse)
async def describe_scene(image: UploadFile = File(...)) -> SceneDescriptionResponse:
    image_bytes = await image.read()
    return service.describe_scene(image.filename or "camera.jpg", image_bytes)
