from fastapi import APIRouter

from app.schemas.navigation import NavigationHintResponse
from app.services.navigation_service import NavigationService

router = APIRouter(prefix="/api/navigation", tags=["navigation"])
service = NavigationService()


@router.get("/hint", response_model=NavigationHintResponse)
def get_navigation_hint() -> NavigationHintResponse:
    return service.get_placeholder_hint()

