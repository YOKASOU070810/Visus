from app.schemas.navigation import NavigationHintResponse


class NavigationService:
    def get_placeholder_hint(self) -> NavigationHintResponse:
        return NavigationHintResponse(
            hint="导航模块占位：后续根据视觉识别结果生成方向提示。",
            priority="normal",
        )

