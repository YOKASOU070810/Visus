from app.schemas.location import LocationStatusResponse


class LocationService:
    def get_placeholder_status(self) -> LocationStatusResponse:
        return LocationStatusResponse(
            tracking_enabled=False,
            message="位置监测模块占位：后续接入用户授权后的定位上传。",
        )

