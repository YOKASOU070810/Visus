from app.schemas.emergency import EmergencyResponse


class EmergencyService:
    def create_placeholder_alert(self) -> EmergencyResponse:
        return EmergencyResponse(
            alert_id="demo-alert",
            status="created",
            message="应急模块占位：后续接入跌倒检测、短信或亲友通知。",
        )

