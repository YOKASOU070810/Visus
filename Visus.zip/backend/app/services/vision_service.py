from app.schemas.vision import SceneDescriptionResponse


class VisionService:
    def describe_scene(self, filename: str, image_bytes: bytes) -> SceneDescriptionResponse:
        return SceneDescriptionResponse(
            summary=f"已收到图片 {filename}，大小 {len(image_bytes)} 字节。AI 识别逻辑待接入。",
            risk_level="unknown",
            next_action="保持当前位置，等待后续识别模块返回真实建议。",
        )

