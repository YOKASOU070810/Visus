# Visus 五人并行开发分工

这个项目先按“接口先行、模块独立”的方式拆分。每个人都可以先在自己的模块里写占位逻辑、测试和页面入口，不需要等待其他人完成真实功能。

## 推荐分工

1. Android 主流程同学：负责 `android-app/app/src/main/java/com/visus/app/MainActivity.java`、页面跳转、权限申请、模块调度。
2. 摄像头与 AI 识别同学：负责 `android-app/.../camera`、`android-app/.../vision`、`backend/app/api/routes/vision.py`、`backend/app/services/vision_service.py`。
3. 语音播报与风险预警同学：负责 `android-app/.../voice`、`android-app/.../risk`、`backend/app/api/routes/navigation.py`、`backend/app/services/navigation_service.py`。
4. 跌倒应急同学：负责 `android-app/.../emergency`、`backend/app/api/routes/emergency.py`、`backend/app/services/emergency_service.py`。
5. 亲友端位置监测同学：负责 `android-app/.../location`、`backend/app/api/routes/location.py`、`backend/app/services/location_service.py`。

## 协作规则

- 每个人只改自己负责的目录，公共文件改动先在群里说清楚。
- 后端新增接口时，先在 `backend/app/schemas` 定义请求和响应数据，再写 `routes`，最后写 `services`。
- 安卓端新增功能时，先在对应包里写独立类，再由 `MainActivity` 或后续的页面调用。
- 每次提交前至少运行一次后端或安卓项目，确认没有明显启动错误。
- API 地址统一从 `ApiClient` 管理，后续可以改成配置文件，不要在多个地方写死地址。

