# Visus 从零运行步骤

本文档按新手流程写，目标是让你们先跑起来一个“没有真实功能、但结构完整”的 Android Demo 和 FastAPI 后端。

## 一、需要安装的软件

1. 安装 Android Studio。
2. 安装 Python 3.11 或 3.12。
3. 安装 Git。
4. 准备一台安卓手机，或使用 Android Studio 自带模拟器。

如果 PowerShell 提示 `python` 不是可识别命令，说明 Python 没装好或没有加入 PATH。重新安装 Python 时勾选 `Add python.exe to PATH`，安装完成后重新打开 PowerShell。

## 二、运行后端 FastAPI

进入项目后端目录：

```powershell
cd C:\Users\余家铮\Documents\Visus\backend
```

创建虚拟环境：

```powershell
python -m venv .venv
```

激活虚拟环境：

```powershell
.\.venv\Scripts\Activate.ps1
```

安装依赖：

```powershell
pip install -r requirements.txt
```

复制环境变量示例文件：

```powershell
copy .env.example .env
```

启动后端：

```powershell
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

打开浏览器访问：

```text
http://127.0.0.1:8000/docs
```

如果能看到 FastAPI 的接口文档，说明后端成功启动。

## 三、运行 Android App

1. 打开 Android Studio。
2. 选择 `Open`。
3. 打开这个目录：`C:\Users\余家铮\Documents\Visus\android-app`。
4. 等待 Android Studio 自动同步 Gradle。
5. 连接安卓手机并打开 USB 调试，或启动模拟器。
6. 点击 Android Studio 顶部的 Run 按钮。

App 启动后会看到 Visus 的 Demo 首页。点击“检查后端连接”可以调用 `/health` 接口。

## 四、手机连接后端地址怎么改

当前 `ApiClient` 默认地址是：

```text
http://10.0.2.2:8000
```

这个地址适用于 Android 模拟器访问电脑本机后端。

如果使用真机，需要把它改成电脑在同一个 Wi-Fi 下的局域网 IP，例如：

```text
http://192.168.1.23:8000
```

修改位置：

```text
android-app/app/src/main/java/com/visus/app/MainActivity.java
```

找到：

```java
apiClient = new ApiClient("http://10.0.2.2:8000");
```

把地址换成你电脑的 IP。

查看电脑 IP 的 PowerShell 命令：

```powershell
ipconfig
```

一般看“无线局域网适配器 WLAN”里的 IPv4 地址。

## 五、代码怎么变成 Android 格式

Android 项目本质上就是一个符合 Gradle 目录规范的工程。本项目已经整理成 Android Studio 可以识别的格式：

```text
android-app/
  settings.gradle
  build.gradle
  app/
    build.gradle
    src/main/
      AndroidManifest.xml
      java/com/visus/app/
      res/layout/
      res/values/
```

只要用 Android Studio 打开 `android-app`，它就会识别为安卓项目。后续你们写的 Java 代码放到 `app/src/main/java/com/visus/app` 下面，页面 XML 放到 `app/src/main/res/layout` 下面，权限写到 `AndroidManifest.xml` 里面。

## 六、当前已经预留的后端接口

- `GET /health`：检查后端是否运行。
- `POST /api/vision/describe`：图片识别接口占位。
- `GET /api/navigation/hint`：导航建议接口占位。
- `POST /api/emergency/alert`：跌倒应急接口占位。
- `GET /api/location/status`：位置监测接口占位。

## 七、下一步建议

1. 先让所有人都成功运行后端和 Android App。
2. 每个人认领 `docs/TEAM_WORKFLOW.md` 里的一个模块。
3. 先不要急着接真实 AI，先把摄像头拍照、上传图片、后端接收图片这条链路跑通。
4. 再接入豆包 API 或 DeepSeek API，把后端 `VisionService` 的占位返回替换成真实识别结果。
